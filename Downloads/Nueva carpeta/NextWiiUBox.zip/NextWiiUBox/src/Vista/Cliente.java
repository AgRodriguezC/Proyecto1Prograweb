/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import Controlador.GestorSesiones;
import Modelo.Cuenta;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowStateListener;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author Cetecom
 */
public class Cliente extends javax.swing.JFrame{

    /**
     * Creates new form Cliente
     */
    public Cliente() {
        initComponents();
        this.setVisible(true);
        this.setLocationRelativeTo(null);
        
        // hacks
        contPrincipal.setBackground(new Color(25, 28, 30));
        contPrincipal.setLayout(null);
        scrollCont.getViewport().setBackground(new Color(25, 28, 30));
        scrollCont.setBorder( null );
        contenidos.setLayout( null );
        contenidos.setOpaque(false);
        
        
        this.addComponentListener( new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                redibujarContenidos();}});
        
        this.addWindowStateListener(new WindowStateListener() {
            @Override
            public void windowStateChanged(WindowEvent e) {
                redibujarContenidos();
            }});
        
        /*for (int i = 0; i < 35; i++) {
            JLabel temp = new JLabel("LOREM IPSUM");
            temp.setForeground(new Color(255,255,255));
            contenidos.add( temp );
        }*/
        
        // estilos
        logo.setForeground(new Color(220,220,220));
        //tiendaBTN.setForeground(new Color(220,220,220));
        tiendaBTN.setForeground(new Color(103,121,135));
        appBTN.setForeground(new Color(103,121,135));
        juegosBTN.setForeground(new Color(103,121,135));
        dlcsBTN.setForeground(new Color(103,121,135));
        
        adminLabel.setForeground(new Color(55,73,82));
        aDevBTN.setForeground(new Color(103,121,135));
        aAppBTN.setForeground(new Color(103,121,135));
        aJuegoBTN.setForeground(new Color(103,121,135));
        aDlcBTN.setForeground(new Color(103,121,135));
        aVendedorBTN.setForeground(new Color(103,121,135));
        aUsrBTN.setForeground(new Color(220,220,220));
        
    }
    private void redibujarContenidos(){
        scrollCont.setBounds(220,0,contPrincipal.getBounds().width - 220, contPrincipal.getBounds().height );
        scrollCont.getViewport().setBounds(0,0,contPrincipal.getBounds().width - 220, contPrincipal.getBounds().height );
        contenidos.setBounds(0,0,contPrincipal.getBounds().width - 220, contPrincipal.getBounds().height );
    }
    
    private void dibujarListaUsuarios(){
        contenidos.removeAll();
        contenidos.setLayout( new BorderLayout() );
        
        Box vert = Box.createVerticalBox();
        contenidos.add(vert, BorderLayout.PAGE_START);
        
        for ( Cuenta usuario : GestorSesiones.getUsuarios() ){
            vert.add( Box.createVerticalStrut(6) );
            JPanel fila = new JPanel();
            fila.setLayout( new GridLayout(0,3) );
            fila.setOpaque(false);
            
            JLabel us = new JLabel( "Usuario : " +  usuario.getNombreUsuario() );
            us.setForeground( new Color(220,220,220));
            
            JLabel rut = new JLabel( "RUT : " + usuario.getRut() + "-" +  usuario.getDv() );
            rut.setForeground( new Color(220,220,220));
            
            JLabel pass = new JLabel(  "Contraseña : " +usuario.getContrasena());
            pass.setForeground( new Color(220,220,220));
            
            JLabel fechaN = new JLabel(  "Fecha Nacimiento : " +usuario.getFechaNacimiento());
            fechaN.setForeground( new Color(220,220,220));
            
            JLabel dir = new JLabel(  "Dirección : " +usuario.getDireccion());
            dir.setForeground( new Color(220,220,220));
            
            JLabel com = new JLabel(  "Comuna : " +usuario.getComuna());
            com.setForeground( new Color(220,220,220));
            
            JLabel fono = new JLabel(  "Telefono : " +usuario.getFono()+"" );
            fono.setForeground( new Color(220,220,220));
            
            JLabel correo = new JLabel(  "Email : " +usuario.getEmail() );
            correo.setForeground( new Color(220,220,220));
            
            JButton mod = new JButton("Modificar");
            mod.setBackground( new Color(25, 28, 30) );
            mod.setForeground( new Color(220,220,220) );
            mod.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                
            }});
            
            JButton del = new JButton("Eliminar");
            del.setBackground( new Color(40, 28, 30) );
            del.setForeground( new Color(220,220,220) );
            del.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                GestorSesiones.eliminarPorUsuario( usuario );
                dibujarListaUsuarios();
            }});
            
            fila.add( us );
            fila.add( rut );
            fila.add( pass );
            fila.add( fechaN );
            fila.add( dir );
            fila.add( com );
            fila.add( fono );
            fila.add( correo );
            //fila.add( mod );
            fila.add( del );
            vert.add(fila);
            
        }
        
        contenidos.revalidate();
        contenidos.repaint();
        
    }
    
    
    
    
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        contPrincipal = new javax.swing.JPanel();
        scrollCont = new javax.swing.JScrollPane();
        contenidos = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        logo = new javax.swing.JLabel();
        tiendaBTN = new javax.swing.JLabel();
        juegosBTN = new javax.swing.JLabel();
        dlcsBTN = new javax.swing.JLabel();
        appBTN = new javax.swing.JLabel();
        adminLabel = new javax.swing.JLabel();
        aJuegoBTN = new javax.swing.JLabel();
        aDlcBTN = new javax.swing.JLabel();
        aAppBTN = new javax.swing.JLabel();
        aDevBTN = new javax.swing.JLabel();
        aVendedorBTN = new javax.swing.JLabel();
        aUsrBTN = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(800, 600));
        setPreferredSize(new java.awt.Dimension(800, 600));

        scrollCont.setOpaque(false);

        contenidos.setAutoscrolls(true);

        javax.swing.GroupLayout contenidosLayout = new javax.swing.GroupLayout(contenidos);
        contenidos.setLayout(contenidosLayout);
        contenidosLayout.setHorizontalGroup(
            contenidosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 560, Short.MAX_VALUE)
        );
        contenidosLayout.setVerticalGroup(
            contenidosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 598, Short.MAX_VALUE)
        );

        scrollCont.setViewportView(contenidos);

        jPanel1.setMinimumSize(new java.awt.Dimension(220, 0));
        jPanel1.setOpaque(false);

        logo.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        logo.setText("NextWiiUBox");

        tiendaBTN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tiendaBTN.setText("Todo");
        tiendaBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        juegosBTN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        juegosBTN.setText("Juegos");
        juegosBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        dlcsBTN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        dlcsBTN.setText("DLCs");
        dlcsBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        appBTN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        appBTN.setText("Aplicativos");
        appBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        adminLabel.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        adminLabel.setText("Opciones Administrativas");
        adminLabel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        aJuegoBTN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        aJuegoBTN.setText("Añadir Juego");
        aJuegoBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        aDlcBTN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        aDlcBTN.setText("Añadir DLC");
        aDlcBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        aAppBTN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        aAppBTN.setText("Añadir Aplicativo");
        aAppBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        aDevBTN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        aDevBTN.setText("Añadir Desarrollador");
        aDevBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        aVendedorBTN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        aVendedorBTN.setText("Añadir Vendedor");
        aVendedorBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        aUsrBTN.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        aUsrBTN.setText("Administrar Usuarios");
        aUsrBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        aUsrBTN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                aUsrBTNMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(adminLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(aUsrBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(aVendedorBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(aDevBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(aAppBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(aDlcBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(aJuegoBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(logo, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(appBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dlcsBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(juegosBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tiendaBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 6, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(logo)
                .addGap(50, 50, 50)
                .addComponent(tiendaBTN)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(juegosBTN)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(dlcsBTN)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(appBTN)
                .addGap(114, 114, 114)
                .addComponent(adminLabel)
                .addGap(14, 14, 14)
                .addComponent(aUsrBTN)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(aJuegoBTN)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(aDlcBTN)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(aAppBTN)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(aDevBTN)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(aVendedorBTN)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout contPrincipalLayout = new javax.swing.GroupLayout(contPrincipal);
        contPrincipal.setLayout(contPrincipalLayout);
        contPrincipalLayout.setHorizontalGroup(
            contPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, contPrincipalLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollCont, javax.swing.GroupLayout.PREFERRED_SIZE, 562, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        contPrincipalLayout.setVerticalGroup(
            contPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrollCont)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contPrincipal, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void aUsrBTNMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_aUsrBTNMouseClicked
        dibujarListaUsuarios();
    }//GEN-LAST:event_aUsrBTNMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cliente.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cliente().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel aAppBTN;
    private javax.swing.JLabel aDevBTN;
    private javax.swing.JLabel aDlcBTN;
    private javax.swing.JLabel aJuegoBTN;
    private javax.swing.JLabel aUsrBTN;
    private javax.swing.JLabel aVendedorBTN;
    private javax.swing.JLabel adminLabel;
    private javax.swing.JLabel appBTN;
    private javax.swing.JPanel contPrincipal;
    private javax.swing.JPanel contenidos;
    private javax.swing.JLabel dlcsBTN;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel juegosBTN;
    private javax.swing.JLabel logo;
    private javax.swing.JScrollPane scrollCont;
    private javax.swing.JLabel tiendaBTN;
    // End of variables declaration//GEN-END:variables

    
}
