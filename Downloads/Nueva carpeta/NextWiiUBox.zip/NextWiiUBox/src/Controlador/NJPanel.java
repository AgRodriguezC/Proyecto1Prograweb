package Controlador;

import javax.swing.JComponent;

/*

    Este es una extensión del JPanel que añade nuevos métodos útiles 

*/

public class NJPanel extends javax.swing.JPanel{
    public int getIndice( JComponent referencia){
        return 0;
    }
    public void despuesDe( JComponent referencia , JComponent porAgregar ){
        
    }
    public void antesDe( JComponent referencia , JComponent porAgregar ){
        
    }
}
