package Controlador;

import Modelo.Cuenta;
import Modelo.Sesion;
import java.util.ArrayList;

public class GestorSesiones {
    private static ArrayList<Sesion> sesiones = new ArrayList<Sesion>();
    private static ArrayList<Cuenta> usuarios = new ArrayList<Cuenta>();
    public static String ultimoError = "";
    
    public static void Inicializar(){
        if ( !usuarios.isEmpty() )
            return;
        usuarios.add( new Cuenta("11.222.333-4", -1,"NA", "NA","NA","NA", "ADMIN","SYS123",true) );
        usuarios.add( new Cuenta("11.222.333-4", -1,"NA", "NA","NA","NA", "TEST","ULTRA",false) );
        // !TODO: Eliminar esta línea en producción
    };
    public static boolean intentarLoggeo(String usuario, String contrasena){
        int indice = -1;
        for (int i = 0; i < usuarios.size() ; i++) {
            if (usuarios.get(i).getNombreUsuario().equals( usuario )){
                indice = i;
                break;
            }
        }
        if (indice == -1){
            ultimoError = "Usuario no encontrado";
            return false;
        }
        if (usuarios.get(indice).getContrasena().equals( contrasena ) ){
            return true;
        }else{
            ultimoError = "Contraseña errónea.";
            return false;
        }
    }
    public static boolean intentarRegistro(String rut, long fono, String direccion, String email, String comuna, String fechaNacimiento, String nombreUsuario, String contrasena, boolean admin){
        
        String _rut = rut.replace(".","");
        int guionIndex = _rut.indexOf("-");
        if (guionIndex == -1){ ultimoError = "Falta un guión en el rut."; return false; }
        
        if ( _rut.substring(guionIndex+1, _rut.length()).length() != 1  ){
            ultimoError = "Digito verificador inválido o no presente."; return false;}
        
        _rut = _rut.substring(0, _rut.indexOf("-"));
        if ( _rut.length() < 7 || _rut.length() > 8 ){
            ultimoError = "Cuerpo del rut no tiene 7 u 8 dígitos."; return false;}
        
        if(nombreUsuario.replace(" ","").length() == 0){
            ultimoError = "Debe proveer un nombre de usuario"; return false;}
        
        if(direccion.replace(" ","").length() == 0){
            ultimoError = "Debe proveer una dirección"; return false;}
        
        if(fechaNacimiento.replace(" ","").length() == 0){
            ultimoError = "Debe proveer una fecha de nacimiento."; return false;}
        
        if(!fechaNacimiento.replace("/","").replace("-","") .matches("[0-9]+")){
            ultimoError = "Fecha inválida. Usa DD/MM/AAAA"; return false;}
        
        if(comuna.replace(" ","").length() == 0){
            ultimoError = "Debe proveer una comuna"; return false;}
        
        if(email.replace(" ","").length() == 0){
            ultimoError = "Debe proveer un email"; return false;}
        
        boolean existe = false;
        for(Cuenta usuario : usuarios){
            if (usuario.getNombreUsuario() == nombreUsuario.replace(" ","")){ existe = true; }
        }
        if (existe){ultimoError = "Nombre de usuario ya registrado."; return false;}
        
        usuarios.add( new Cuenta(
                rut,
                fono,
                direccion.replace(" ",""),
                email.replace(" ",""),
                comuna.replace(" ",""),
                fechaNacimiento.replace(" ",""),
                nombreUsuario.replace(" ",""),
                contrasena, 
                false) );
        
        return true;
    }

    public static ArrayList<Cuenta> getUsuarios() {
        return usuarios;
    }
    public static void eliminarPorUsuario(Cuenta usuarioPorBorrar){
        usuarios.remove( usuarioPorBorrar );
    }
    
}