package Modelo;


public class Cuenta {
    private int rut;
    private char dv;
    private long fono;
    private String direccion, email, comuna, fechaNacimiento;
    private String nombreUsuario, contrasena;
    private boolean admin;
    
    // !TODO: Almacenar Hash de la contraseña + salt en vez de la contraseña.
    
    public Cuenta(String rut, long fono, String direccion, String email, String comuna, String fechaNacimiento, String nombreUsuario, String contrasena, boolean admin){
        this.rut = Integer.parseInt( rut.substring(0, rut.indexOf("-")).replace(".","") );
        this.dv = rut.charAt(rut.indexOf("-")+1);
        this.fono = fono;
        this.direccion = direccion;
        this.email = email;
        this.comuna = comuna;
        this.fechaNacimiento = fechaNacimiento;
        this.contrasena = contrasena;
        this.nombreUsuario = nombreUsuario;
        this.admin = admin;
    }

    public int getRut() {
        return rut;
    }

    public char getDv() {
        return dv;
    }

    public long getFono() {
        return fono;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getEmail() {
        return email;
    }

    public String getComuna() {
        return comuna;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public String getContrasena() {
        return contrasena;
    }
}
