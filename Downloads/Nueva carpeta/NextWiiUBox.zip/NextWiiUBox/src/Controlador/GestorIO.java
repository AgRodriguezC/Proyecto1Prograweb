package Controlador;
public class GestorIO {
    private GestorIO(){}; // Hacer ininstanciable
    
}
